﻿using System;

namespace Insma.Mxa.Framework.Graphics {
	public enum GraphicsDeviceStatus {
		Normal = 0,
		Lost = 1,
		NotReset = 2,
	}
}
