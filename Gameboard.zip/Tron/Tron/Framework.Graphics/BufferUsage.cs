﻿using System;

namespace Insma.Mxa.Framework.Graphics {
	public enum BufferUsage {
		None = 0,
		WriteOnly = 1,
	}
}
