﻿//-----------------------------------------------------------------------
// <copyright file="HighScoreEntry.xaml.cs" company="Group 2">
//     All Rights Reserved
// </copyright>
//-----------------------------------------------------------------------

namespace Tetris
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Data;
    using System.Windows.Documents;
    using System.Windows.Input;
    using System.Windows.Media;
    using System.Windows.Media.Imaging;
    using System.Windows.Shapes;
    using Objects;
    using System.IO;

    /// <summary>
    /// Interaction logic for HighScoreEntery.xaml
    /// </summary>
    public partial class HighScoreEntery : Window
    {
        // Represents mainform
        public Window mainForm;

        /// <summary>
        /// Creates a new Highscore
        /// </summary>
        private HighScore highScore = new HighScore();

        public HighScoreEntery(Window Mainform)
        {
            InitializeComponent();
            mainForm = Mainform;
        }

        public HighScoreEntery()
        {
            InitializeComponent();
        }

        private void btnSubmitNRestart_Click(object sender, RoutedEventArgs e)
        {
            // Rewrite score data to file 
            SubmitScore();

            //Close form and start a new game
            mainForm.Close();
            MainWindow NewGame = new MainWindow();
            this.Close();
            NewGame.ShowDialog();
        }

        // Method for submitting score
        private void SubmitScore()
        {
            // Declare variables to hold user input, and there score
            string userName = txtUserInput.Text;

            // Check if user entered text
            if (userName != "")
            {

                if (userName.Length == 3)
                {

                    if (char.IsLetter(userName,0) && char.IsLetter(userName, 1) && char.IsLetter(userName, 2))
                    {
                        StreamReader inputFile;
                        // Get user score
                        // Get gamedata
                        inputFile = File.OpenText("../../highscores/gamedata.txt");

                        // Set variable to store users highscore
                        string score = inputFile.ReadLine().Remove(0,5);

                        // Close inputFile
                        inputFile.Close();

                        // Create a variable that holds formatted score data
                        string saveData = userName + "-" + score;

                        highScore.SetScores(saveData);
                    }
                    else
                    {
                        MessageBox.Show("Please enter a name consisting only letters");
                    }
                }
                else
                {
                    MessageBox.Show("Please enter a name consisting of 3 letters");
                }
            }
            else
            {
                MessageBox.Show("Please enter a name to save your score under");
            }

        }

        private void btnSubmitNClose_Click(object sender, RoutedEventArgs e)
        {
            // Rewrite score data to file 
            SubmitScore();

            // Close app
            Application.Current.Shutdown();
        }
    }
}
