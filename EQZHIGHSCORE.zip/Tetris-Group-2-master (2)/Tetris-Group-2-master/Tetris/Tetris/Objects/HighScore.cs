﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Text;

namespace Tetris.Objects
{
    public class HighScore
    {
        // Array for holding scores that are to be read from the file
        public string[] highScorers = new string[10];
        public int[] highScorez = new int[10];
        public string[] highScoreData = new string[10];

        // Method for sorting scores
       public void SortScores()
        {
            // Declare values to hold the value and index of the smallest number in the array
            int minIndex;
            int minValue;

            // Loop through array to find where scan begins
            for (int startScan = 0; startScan < highScorez.Length - 1; startScan++)
            {
                // Assume first posistion is the smallest
                minIndex = startScan;
                minValue = highScorez[startScan];

                // Find the min value in the array
                for (int i = startScan + 1; i < highScorez.Length; i++)
                {
                    if (highScorez[i] > minValue)
                    {
                        minValue = highScorez[i];
                        minIndex = i;
                    }
                }

                // Swap the element with the smallest value with the first element in the scanable area
                SwapScore(ref highScorez[minIndex], ref highScorez[startScan]);
                SwapName(ref highScorers[minIndex], ref highScorers[startScan]);

                // Begin adding sorted data to master highscores array
                string scoreData = highScorez[minIndex].ToString();
                string allScoreData = highScorers[minIndex] + "-" + scoreData;
                highScoreData[minIndex] = allScoreData;

            }
        }

        // Create the swap method
        private void SwapScore(ref int a, ref int b)
        {
            int c = a;
            a = b;
            b = c;
        }

        private void SwapName(ref string a, ref string b)
        {
            string c = a;
            a = b;
            b = c;
        }

        // Read data from highscore files
        public void GetScores()
        {

            // Declare a stream reader to get scores from text file
            StreamReader inputFile;
            inputFile = File.OpenText("../../highscores/highscores.txt");

            //Loop through file and send text to given array
            for (int i = 0; i < 10; i++)
            {
                highScoreData[i] = (inputFile.ReadLine());

                // take the numeric data from highScoreData
                int num = int.Parse(highScoreData[i].Remove(0, 4));
                highScorez[i] = num;

                // take the string data from highScoreData
                string name = highScoreData[i].Remove(3);
                highScorers[i] = name;
            }

            // Run sorting method to make sure scores are in order
            SortScores();

            // Close text file
            inputFile.Close();
        }


        public void SetScores(string scoreData)
        {
            // Get all scores
            GetScores();

            // Overwrite the current highscores file and set the first highscore
            File.WriteAllText("../../highscores/highscores.txt", highScoreData[0]);

            // Declare a streamwriter, append the rest of the highscores to the file
            StreamWriter outputFile;
            outputFile = File.AppendText("../../highscores/highscores.txt");
            for (int i = 0; i < highScorez.Length - 1; i++)
            {
                outputFile.WriteLine(highScoreData[i]);
            }
            // Write players new highscore into highscores file
            outputFile.WriteLine(scoreData);

            // Close the output file
            outputFile.Close();
        }
       
    }
}
