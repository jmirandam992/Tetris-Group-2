﻿using System;

namespace Insma.Mxa.Framework.Graphics {
	public enum DepthFormat {
		None = 0,
		Depth16 = 1,
		Depth24 = 2,
		Depth24Stencil8 = 3,
	}
}
