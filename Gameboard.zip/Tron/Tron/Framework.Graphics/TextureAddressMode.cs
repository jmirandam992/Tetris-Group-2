﻿using System;

namespace Insma.Mxa.Framework.Graphics {
	public enum TextureAddressMode {
		Wrap = 0,
		Clamp = 1,
		Mirror = 2,
	}
}
