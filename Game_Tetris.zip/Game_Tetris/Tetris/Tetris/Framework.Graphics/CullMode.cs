﻿using System;

namespace Insma.Mxa.Framework.Graphics {
	public enum CullMode {
		None = 0,
		CullClockwiseFace = 1,
		CullCounterClockwiseFace = 2,
	}
}
