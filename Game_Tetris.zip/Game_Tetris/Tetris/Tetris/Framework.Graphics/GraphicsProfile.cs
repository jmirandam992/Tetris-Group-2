﻿using System;

namespace Insma.Mxa.Framework.Graphics {
	public enum GraphicsProfile {
		Reach = 0,
		HiDef = 1,
	}
}
