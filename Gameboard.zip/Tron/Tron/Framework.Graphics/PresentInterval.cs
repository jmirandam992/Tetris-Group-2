﻿using System;

namespace Insma.Mxa.Framework.Graphics {
	public enum PresentInterval {
		Default = 0,
		One = 1,
		Two = 2,
		Immediate = 3,
	}
}
