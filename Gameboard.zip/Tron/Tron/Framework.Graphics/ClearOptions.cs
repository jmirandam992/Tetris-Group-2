﻿using System;

namespace Insma.Mxa.Framework.Graphics {
	public enum ClearOptions {
		Target = 1,
		DepthBuffer = 2,
		Stencil = 4,
	}
}
