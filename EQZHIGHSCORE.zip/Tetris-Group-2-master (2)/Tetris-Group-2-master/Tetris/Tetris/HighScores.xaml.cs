﻿//-----------------------------------------------------------------------
// <copyright file="HighScores.xaml.cs" company="Group 2">
//     All Rights Reserved
// </copyright>
//-----------------------------------------------------------------------

namespace Tetris
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Data;
    using System.Windows.Documents;
    using System.Windows.Input;
    using System.Windows.Media;
    using System.Windows.Media.Imaging;
    using System.Windows.Shapes;
    using Tetris;
    using Objects;

    /// <summary>
    /// Interaction logic for HighScores.xaml
    /// </summary>
    public partial class HighScores : Window
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="HighScores"/> class.
        /// </summary>
        /// 

        /// <summary>
        /// Creates a new Highscore
        /// </summary>
        private HighScore highScore = new HighScore();

        public HighScores()
        {
            this.InitializeComponent();

            // Get all highscores and the holders of them
            highScore.GetScores();

            // set all the name labels
            lblName1.Content = highScore.highScorers[0];
            lblName2.Content = highScore.highScorers[1];
            lblName3.Content = highScore.highScorers[2];
            lblName4.Content = highScore.highScorers[3];
            lblName5.Content = highScore.highScorers[4];
            lblName6.Content = highScore.highScorers[5];
            lblName7.Content = highScore.highScorers[6];
            lblName8.Content = highScore.highScorers[7];
            lblName9.Content = highScore.highScorers[8];
            lblName10.Content = highScore.highScorers[9];

            // set all the highscore labels
            lbl1Score.Content = highScore.highScorez[0];
            lbl2Score.Content = highScore.highScorez[1];
            lbl3Score.Content = highScore.highScorez[2];
            lbl4Score.Content = highScore.highScorez[3];
            lbl5Score.Content = highScore.highScorez[4];
            lbl6Score.Content = highScore.highScorez[5];
            lbl7Score.Content = highScore.highScorez[6];
            lbl8Score.Content = highScore.highScorez[7];
            lbl9Score.Content = highScore.highScorez[8];
            lbl10Score.Content = highScore.highScorez[9]; 
        }

        /// <summary>
        /// backButton_Click method
        /// </summary>
        /// <param name="sender">Back button click</param>
        /// <param name="e">Event Arguments</param>
        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            // StartScreen.GetWindow();
            this.Hide();
        }

        /// <summary>
        /// To move the window around.
        /// </summary>
        /// <param name="sender">Move the window</param>
        /// <param name="e">Event Arguments</param>
        private void Grid_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
                this.DragMove();
            }
    }
        
    }
}
