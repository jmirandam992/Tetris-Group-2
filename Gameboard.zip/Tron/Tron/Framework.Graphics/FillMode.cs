﻿using System;

namespace Insma.Mxa.Framework.Graphics {
	public enum FillMode {
		Solid = 0,
		WireFrame = 1,
	}
}
