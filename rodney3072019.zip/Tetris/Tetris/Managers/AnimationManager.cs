﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Documents;

namespace Tron
{
    public class AnimationManager
    {
        private Animation _animation;
        private float _timer;
    }
}
