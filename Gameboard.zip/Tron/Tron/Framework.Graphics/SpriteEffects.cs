﻿using System;

namespace Insma.Mxa.Framework.Graphics {
	public enum SpriteEffects {
		None = 0,
		FlipHorizontally = 1,
		FlipVertically = 2,
	}
}
