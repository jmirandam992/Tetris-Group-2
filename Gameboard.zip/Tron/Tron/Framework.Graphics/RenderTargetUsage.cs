﻿using System;

namespace Insma.Mxa.Framework.Graphics {
	public enum RenderTargetUsage {
		DiscardContents = 0,
		PreserveContents = 1,
		PlatformContents = 2,
	}
}
