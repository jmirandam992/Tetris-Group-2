﻿using System;

namespace Insma.Mxa.Framework.Graphics {
	public enum EffectParameterClass {
		Scalar = 0,
		Vector = 1,
		Matrix = 2,
		Object = 3,
		Struct = 4,
	}
}
