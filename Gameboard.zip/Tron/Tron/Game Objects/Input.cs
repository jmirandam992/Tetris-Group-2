﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Input;

namespace Tron
{
    public class Input
    {
        public Key Up { get; set; }
        public Key Right { get; set; }
        public Key Down { get; set; }
        public Key Left { get; set; }
    }
}
