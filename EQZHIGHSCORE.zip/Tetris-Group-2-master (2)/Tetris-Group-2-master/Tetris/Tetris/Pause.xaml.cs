﻿//-----------------------------------------------------------------------
// <copyright file="Pause.xaml.cs" company="Group 2">
//     All Rights Reserved
// </copyright>
//-----------------------------------------------------------------------


namespace Tetris
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Data;
    using System.Windows.Documents;
    using System.Windows.Input;
    using System.Windows.Media;
    using System.Windows.Media.Imaging;
    using System.Windows.Shapes;
    using System.IO;
    using Objects;

    /// <summary>
    /// Interaction logic for Pause.xaml
    /// </summary>
    public partial class Pause : Window
    {
        /// <summary>
        /// Creates a new Highscore
        /// </summary>
        private HighScore highScore = new HighScore();

        // Used for holding score data
        private string pScore;

        public Window mainForm;

        // Declare a stream reader to get scores from text file
        StreamReader inputFile;
        

        public Pause(Window Mainform)
        {
            InitializeComponent();
            mainForm = Mainform;

            // Get gamedata
            inputFile = File.OpenText("../../highscores/gamedata.txt");

            // Set variables to store gamedata
            string score = inputFile.ReadLine();
            string lines = inputFile.ReadLine();
            //string time = inputFile.ReadLine();
            //string level = inputFile.ReadLine();

            // Close inputFile
            inputFile.Close();

            // score data that can be read from all of the pause menu
            pScore = score.Remove(0, 5);

            // Set game statistics labels
            lblScoreOutput.Content = pScore;
            lblLinesOutput.Content = lines.Remove(0, 5);
            //lblTimeOutput.Content = time.Remove(0, 5);
            //lblLevelOutput.Content = level.Remove(0, 5);

        }

        /// <summary>
        /// Close button.
        /// </summary>
        private void btnResume1_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
            mainForm.Visibility = Visibility.Visible;
        }

        /// <summary>
        /// Resets the game button.
        /// </summary>
        private void btnReset_Click(object sender, RoutedEventArgs e)
        {
            mainForm.Close();
            MainWindow NewGame = new MainWindow();
            this.Close();
            NewGame.ShowDialog();
        }

        /// <summary>
        /// Quits the game button.
        /// </summary>
        private void btnQuit_Click(object sender, RoutedEventArgs e)
        {
            // Get the current list of highscores
            highScore.GetScores();

            //Check if player has gotten a highscore
            if (highScore.highScorez[9] < int.Parse(pScore))
            { 
                // Overwrite the current gamedata file and set the first value: score
                File.WriteAllText("../../highscores/gamedata.txt", "scor:" + lblScoreOutput.Content);

                // Open highscores window
                HighScoreEntery highScoreWindow = new HighScoreEntery();
                this.Visibility = Visibility.Hidden;
                highScoreWindow.ShowDialog();
            }

            // Close app
            this.Close();
            System.Windows.Application.Current.Shutdown();
        }

        /// <summary>
        /// To move the window around.
        /// </summary>
        private void grdPauseLayout_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
                DragMove();
            }
        }
    }
}
